#!/bin/sh
echo "STARTING - $(date)"
