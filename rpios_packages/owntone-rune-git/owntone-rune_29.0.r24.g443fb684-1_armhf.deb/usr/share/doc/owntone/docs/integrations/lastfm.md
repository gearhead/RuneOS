# LastFM

You can have OwnTone scrobble the music you listen to. To set up scrobbling
go to the web interface and authorize OwnTone with your LastFM credentials.

OwnTone will not store your LastFM username/password, only the session key.
The session key does not expire.
