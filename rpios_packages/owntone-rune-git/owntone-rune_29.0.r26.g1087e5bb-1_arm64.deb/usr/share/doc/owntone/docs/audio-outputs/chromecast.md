# Chromecast

OwnTone will discover Chromecast devices available on your network, and you
can then select the device as a speaker. There is no configuration required.

Take note that:

- Chromecast playback can't be precisely sync'ed with other outputs e.g. AirPlay
- Playback to Google Nest Hub doesn't work (Nest Mini does work)
